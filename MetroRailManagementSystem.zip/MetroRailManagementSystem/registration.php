

<?php
session_start();
include "includes/db_connect.inc.php";
$url="login.php";

if(isset($_SESSION["type"]) && $_SESSION["type"]=="Admin" ){
    $url="./admin/admin.php";
  }
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Manager" ){
    $url="./manager/manager.php";
  }   
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Passenger" ){
    $url="./passenger/passenger.php";
  }   

 $Id = $Name = $Age = $Gender = $Type = $Address = $Email = $Phone_Number = $sqlUserCheck = $Password = $Err = $IdInDB = $result = "" ;
	
	
	/* mysqli_real_escape_string() helps prevent sql injection */
  if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(!empty($_POST['id'])){
      $Id = mysqli_real_escape_string($conn, $_POST['id']);
    }
    if(!empty($_POST['name'])){
      $Name = mysqli_real_escape_string($conn, $_POST['name']);
    }
    if(!empty($_POST['age'])){
      $Age = mysqli_real_escape_string($conn, $_POST['age']);
    }
	if(!empty($_POST['gender'])){
      $Gender = mysqli_real_escape_string($conn, $_POST['gender']);
    }
    if(!empty($_POST['password'])){
      $Password = mysqli_real_escape_string($conn, $_POST['password']);
      $Password = password_hash($Password, PASSWORD_DEFAULT);
    }
    if(!empty($_POST['type'])){
      $Type = mysqli_real_escape_string($conn, $_POST['type']);
	  if($Type=="Manager"){
		  $sqlUserCheck = "SELECT id FROM managertable WHERE id = '$Id'";
	  }
	  if($Type=="Passenger"){
		  $sqlUserCheck = "SELECT id FROM passengertable WHERE id = '$Id'";
	  }
    }
	if(!empty($_POST['address'])){
      $Address = mysqli_real_escape_string($conn, $_POST['address']);
    }
	if(!empty($_POST['email'])){
      $Email = mysqli_real_escape_string($conn, $_POST['email']);
    }
	if(!empty($_POST['phone_number'])){
      $Phone_Number = mysqli_real_escape_string($conn, $_POST['phone_number']);
	 
    }

    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $IdInDB = $row['id'];
    }
	$sqlUserCheck2="SELECT id FROM applicanttable WHERE id = '$Id'";
	$result2 = mysqli_query($conn, $sqlUserCheck2);

    while($row = mysqli_fetch_assoc($result2)){
      $IdInDB = $row['id'];
    }
    if($IdInDB == $Id){
      $Err = "ID already exists!";
    }
    else{
      $sql = "INSERT INTO applicanttable (id,name,age,gender,type,address,gmail,pno,password)
              VALUES ('$Id','$Name','$Age','$Gender','$Type','$Address','$Email','$Phone_Number','$Password');";

      mysqli_query($conn, $sql);
    }
  }

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="home.php">Home</a></li>
            <li ><a href="<?php echo $url ?>">LOG IN</a></li>
            <li class="current"><a href="registration.php">Registration</a></li>
			<li><a href="details.php">Details</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section class="container">
     <h1 align="center">Registration</h1>
		<form action="registration.php" method="POST">
			<table align="center" id="sidebar1">
				<tr>
					<th><label> Id: </label></th>
					<td><input type="text" name="id" value="<?php echo $Id;?>"  required></td>
				</tr>
					<tr>
					<th><label> Name: </label></th>
					<td><input type="text" name="name" value="<?php echo $Name;?>" required></td>
				</tr>

				<tr>
					<th><label> Age: </label></th>
					<td><input type="text" name="age" value="<?php echo $Age;?>" required></td>
				</tr>
				<tr>
					<th><label >Gender: </label></th>
					<td>
					<select name="gender" >
					<option name="gender" value="Male" <?php if (isset($Gender) && $Gender=="Male") echo "selected";?>> Male</option>
					<option name="gender" <?php if (isset($Gender) && $Gender=="Female") echo "selected";?>>Female</option>
					<option name="gender" <?php if (isset($Gender) && $Gender=="Other") echo "selected";?>>Other</option>
					</select>
					</td>
			    </tr>
				<tr>
					<th><label>User Type: </label></th>
					<td>
					<select name="type" value="<?php echo $Type;?>">
					<option name="type" value="Manager"<?php if (isset($Gender) && $Gender=="Manager") echo "selected";?>> Manager</option>
					<option name="type" value="Passenger" <?php if (isset($Gender) && $Gender=="Passenger") echo "selected";?>>Passenger</option>
					</select>
					</td>
			    </tr>
			<tr>
			<th><label> Address: </label></th>
			<td><input type="text" name="address" value="<?php echo $Address;?>" required></td>
			</tr>

			<tr>
			<th><label> Email: </label></th>
			<td><input type="Email" name="email"  value="<?php echo $Email;?>" required></td>
			</tr>

			<tr>
			<th><label> Phone Number: </label></th>
			<td><input type="text" name="phone_number" value="<?php echo $Phone_Number;?>" required></td>
			</tr>


			<tr>
			<th><label> Password: </label></th>
			<td><input type="password" name="password" value="<?php echo $Password;?>" required></td>
			</tr>

			<tr>
			<td></td>
			<td align ="right"><button type="submit" onClick="update()" id="a1">Submit</button></td>
			<td>
             <span style="color:red;"><?php echo $Err; ?></span>
             <span><b>Or Log In <a href="login.php">here</a> if have an account already</b></span>
			 </td>
			</tr>  
			</table>
		</form>
    </section>
	<script>
function update(){
 var x;
 if(confirm("Registered Sucessfully") == true){
 x= "update";
 }
}
</script>
    <footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
