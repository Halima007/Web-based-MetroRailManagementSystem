

<?php 
session_start();
$url="login.php";

if(isset($_SESSION["type"]) && $_SESSION["type"]=="Admin" ){
    $url="./admin/admin.php";
  }
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Manager" ){
    $url="./manager/manager.php";
  }  
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Passenger" ){
    $url="./passenger/passenger.php";
  }  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='./css/style.css' />
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="home.php">Home</a></li>
            <li><a href="<?php echo $url ?>">log in</a></li>
            <li><a href="registration.php">Registration</a></li>
			<li><a href="details.php">Details</a></li>
          </ul>
        </nav>
      </div>
    </header>

<div class="slideshow-container">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="./img/image.jpg" style="width:100%">
    <div class="text">Caption Text</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="./img/image1.jpg" style="width:100%">
    <div class="text">Caption Two</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="./img/image2.jpg" style="width:100%">
    <div class="text">Caption Three</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>





<script>
var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}

</script>

    <footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
  </html>
