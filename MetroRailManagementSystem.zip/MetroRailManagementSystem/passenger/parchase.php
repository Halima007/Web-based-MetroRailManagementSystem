<?php

session_start();
include "../includes/db_connect.inc.php";

$pId=$pName = $pBalance =$err =  $uNameInDB =$stp= "" ;
$pId =$_SESSION["id"];
$i=$j=0;
$cost=$add=0;
$arr=array();

                   $sql2="SELECT * FROM raildetails where id= '1' ;";
	                if($result2 = mysqli_query($conn, $sql2)) {
		            while($rows2 = mysqli_fetch_array($result2)){
		            $mark=explode(",",$rows2['stoppage']);
			
						 foreach($mark as $stp){
	                      if(isset($_POST['submit'])){
			              if($_POST['source']==$stp){
							  break;
							  
			              }
						  }
						  $i=$i+1;					 
					 }
						 foreach($mark as $stp){
	                      if(isset($_POST['submit'])){
			              if($_POST['dest']==$stp){
							  break;
							  
			              }
						  }
						  $j=$j+1;	
						  
					 }
				          $add=abs($i-$j);
						  $cost= $add*5;
						  
					 
					 
					 foreach($arr as $x=>$x_value){
						 
						 }
						 
					 	
		}
		
		}

					
	

	 
	 
	 ///
      $sql = "SELECT * FROM passengertable where id= '$pId' ;";
	  
			  
      $result = mysqli_query($conn, $sql);
	  $rows = mysqli_num_rows($result);
        //     //echo'USER EXIST';
        if ($rows==1){
            while($rs  = mysqli_fetch_array($result)){ 
                 $pId = $rs['id'];
                 $pName=$rs['name'];
				 $pBalance=$rs['balance'];
				 
				 

             }
         }
		 if(isset($_POST['submit'])){
			 if($pBalance<$cost){
				 
			 }
			 else
			$pBalance= $pBalance-$cost;
			
			 $sql2="UPDATE passengertable set balance='$pBalance' where id='$pId';";
			 $up=mysqli_query($conn, $sql2);
		}
		 
		 
		 
		 
		 
		 
  


?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='../css/style.css' />
  </head>


<body>
<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li><a href="passenger.php">Profile</a></li>
            <li><a href="recharge.php">Recharge</a></li>
            <li class="current"><a href="parchase.php">Purchase</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a></li>
          </ul>
        </nav>
      </div>
    </header>
	
	
	<script type="text/javascript" src="jquery-3.3.1.js"></script>
	<script type="text/javascript" src="custom.js"></script>
	
	
	
	
<form action ="parchase.php" method="POST" >
    <section id="boxes">
      <div class="container">
        <table>
		<tr>
    	<td> <label>ID: </label></td>
		<td> <label ><?php echo $pId;?></label></td>
		
		</tr>
		<tr>
		<td> <label>Name: </label></td>
        <td><input name ="p_name" value="<?php echo $pName;?>">
		<div id="contnet"></div>
		</input></td>
		</tr>
		<tr>
		<td> <label>Balance: </label></td>
		<td> <label name="bl"> <?php echo $pBalance;?></label></td>
		
		</tr>
		
		<tr>
					<td><label>Source:</label></td>
					<td>
					<select name="source"  >
					<option name=src value="" disabled selected >Select Source</option>
					<?php
					$sql2="SELECT * FROM raildetails where id= '1' ;";
	                if($result2 = mysqli_query($conn, $sql2)) {
		            while($rows2 = mysqli_fetch_array($result2)){
		            $mark=explode(",",$rows2['stoppage']);
		             foreach($mark as $stp){?>
				       <option ><?php echo $stp; ?></option>
					   <?php
			         echo $stp. "<br/>";
		}
		
		}
	}?>

					</select>
					</td>
				</tr>
				
		<tr>
					<td><label>Destination:</label></td>
					<td>
					<select name="dest" >
					<option name=src value="" disabled selected >Select Destination</option>
					<?php
					$sql2="SELECT * FROM raildetails where id= '1' ;";
	                if($result2 = mysqli_query($conn, $sql2)) {
		            while($rows2 = mysqli_fetch_array($result2)){
		            $mark=explode(",",$rows2['stoppage']);
		             foreach($mark as $stp){?>
				       <option  ><?php echo $stp; ?></option>
					   <?php
			         echo $stp. "<br/>";
		}
		
		}
	}?>
	
	
					</select>
					</td>
				</tr>
				<tr>
				<td> Cost</td>
				<td> <label > <?php echo $cost ; ?></label></td>
				</tr>
				<tr>
				<td colspan="2"><label>Click purchase, if you want to purchase.</label></td>
				</tr>
		<tr>
       <td colspan="2" align="right"><button type="submit" name= "submit" value="submit" >purchase </button></td>
       </tr>
       
	</table>
		   
      </div>
    </section>
	</form>
	
	
	

	<footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
  </html>
