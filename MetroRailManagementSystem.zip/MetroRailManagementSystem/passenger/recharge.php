<?php
session_start();
include "../includes/db_connect.inc.php";

$pId= $pBalance=$sum =$err = $uNameInDB = "" ;
 $pId =$_SESSION["id"];
 
 $sql = "SELECT balance FROM passengertable where id= '$pId';";
			  
      $result = mysqli_query($conn, $sql);
      $rows = mysqli_num_rows($result);
			 
			  if ($rows==1){
            while($rs  = mysqli_fetch_array($result)){ 
                $pBalance = $rs['balance'];
				  
             }
         }
		 if(isset($_POST['submit']))
{
$x=$_POST['cb'];		
$y=$_POST['am'];				
$sum=$x+$y;		 	  
			 $sql2="UPDATE passengertable set balance='$sum' where id='$pId';";
			 $up=mysqli_query($conn, $sql2);
			 
			 if(!isset($sql)){
				 die("Error $sql".mysqli_connect_error);
			 }
			 else
			 {
				 header("location:recharge.php");
			 }
			 
		 }
		 
		  


?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='../css/style.css' />
  </head>


<body>
<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
		   <li><a href="../home.php">Home</a></li>
		  <li><a href="passenger.php">Profile</a></li>
            <li class="current"><a href="recharge.php">Recharge</a></li>
            <li><a href="parchase.php">Purchase</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a></li>
          </ul>
        </nav>
      </div>
    </header>
	
		
<form action ="recharge.php" method="POST">
    <section id="boxes">
      <div class="container">
	<table>
	<tr>
	<td>Current Balance: </td>
	<td><label><?php echo $pBalance;?></label> <input type="hidden" name="cb" value="<?php echo $pBalance;?>"></td>	   		   
    </tr>
    <tr>
	<td> Amount:</td>
	<td><input type="text" name="am" required /></td>
    </tr>
    <tr>
    <td><button type="submit" name="submit" value="recharge" >Recharge</button></td>
	</tr>
	</table>
    </div>	
	
	<div>
    <label><h4>Want to recharge from your existing account? </h4></label>
	<label> Choose your payment method: </label><br>
	
	<section id="boxes">
      <div class="container">
        <div class="box">
          
          <p><a href="https://www.bkash.com/app/"><img src="../img/bksh.jpg" style="width:150px;height:150px;"></a></p>
 
        </div>
		<div class="box">
          
          <p><a href="https://dutchbanglabank.com/rocket/rocket.html"><img src="../img/rocket.jpg" style="width:150px;height:150px;"></a></p>
 
        </div>
		
		<div class="box">
          
          <p><a href="https://www.bkash.com/app/"><img src="../img/bksh.jpg" style="width:150px;height:150px;"></a></p>
 
        </div>
      </div>
    </section>
	</div>
	 </section>
	 </form>
	 

 

<footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
	 </body>
  </html>