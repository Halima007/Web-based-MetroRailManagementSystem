$('#button').click(function(){
	$("#contnet").load (parchase.php)
};)
