<?php

session_start();
include "../includes/db_connect.inc.php";

$pName = $pAge = $pGender= $pAddress=$pNo =$pEmail = $pPass= $pBalance =$err = $uNameInDB =$pPassup= "" ;
$pId =$_SESSION["id"];
$pPass=$_SESSION["password"];


	
	 
      $sql = "SELECT * FROM passengertable where id= '$pId' ;";
	  
			  
      $result = mysqli_query($conn, $sql);
	  $rows = mysqli_num_rows($result);
        //     //echo'USER EXIST';
        if ($rows==1){
            while($rs  = mysqli_fetch_array($result)){ 
                 
                 $pName=$rs['name'];
				 $pAge=$rs['age'];
				 $pGender=$rs['gender'];
				 $pAddress=$rs['address'];
				 $pno=$rs['pno'];
				 $pEmail=$rs['gmail'];
				
				 $pBalance=$rs['balance'];
				 

             }
         }
		 
		 
		 
		 // edit 
		 if(isset($_POST['Edit'])){
			 $pName=$_POST['p_name'] ;
			 $pAge=$_POST['p_age'];
			 $pAddress=$_POST['p_add'];
			 $pno=$_POST['p_pno'];
			 $pEmail=$_POST['p_email'];
			 $pPass=$_POST['p_pass'];
			 $_SESSION["password"]=$pPass;
			 $pPassup=password_hash($pPass, PASSWORD_DEFAULT);
			 $sql2="UPDATE passengertable set name='$pName', age='$pAge',address='$pAddress',pno='$pno',gmail='$pEmail',password='$pPassup' where id='$pId';";
			 $up=mysqli_query($conn, $sql2);
			 
			 if(!isset($sql)){
				 die("Error $sql".mysqli_connect_error);
			 }
			 else
			 {
				 header("location:passenger.php");
			 }
		 }
		 
  


?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='../css/style.css' />
  </head>


<body>
<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li class="current"><a href="passenger.php">Profile</a></li>
            <li><a href="recharge.php">Recharge</a></li>
            <li><a href="parchase.php">Purchase</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a></li>
          </ul>
        </nav>
      </div>
    </header>
	
	
	
	
	
<form action ="passenger.php" method="POST">
    <section id="boxes">
      <div class="container">
	  <h1 align="center" style="color:red">Welcome, <?php echo $pName ?></span></h1>
	  <img align="right"src="../img/pro_pic.jpg" style="width:200px;height:200px;" >
        <table>
		<tr>
    	<td> <label>ID: </label></td>
		<td> <label ><?php echo $pId;?></label></td>
		
		</tr>
		<tr>
		<td> <label>Name: </label></td>
        <td><input name ="p_name" value="<?php echo $pName;?>"> </input></td>
		</tr>
		
		<tr>
        <td> <label>Age: </label></td>
		<td><input name="p_age" value="<?php echo $pAge;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>gender: </label></td>
		<td><label><?php echo $pGender;?></label></td>
		</tr>
		<tr>
		<td> <label>Address: </label></td>
        <td><input name="p_add" value="<?php echo $pAddress;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Phone: </label></td>
		<td><input name="p_pno" value="<?php echo $pno;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Email: </label></td>
		<td><input name="p_email" value="<?php echo $pEmail;?>"> </input></td>
		<tr>
		<td> <label>Password: </label></td>
         <td><input name="p_pass" value="<?php echo $pPass;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Balance: </label></td>
		<td> <label> <?php echo $pBalance;?></label></td>
		
		</tr>
		<tr>
       <td><button type="submit" name= "Edit" value="Edit" onClick="update()">Edit</button></td>
       </tr>
       <tr>
		</table>
		   
      </div>
    </section>
	</form>
	<script>
function update(){
 var x;
 if(confirm("Updated data Sucessfully") == true){
 x= "update";
 }
}
</script>
	

	<footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
  </html>
