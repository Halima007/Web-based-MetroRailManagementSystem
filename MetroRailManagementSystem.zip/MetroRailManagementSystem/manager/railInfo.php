<?php
session_start();
include "../includes/db_connect.inc.php";

$rNo =$current = $next =$err= $uNameInDB =  "" ;
$mId =$_SESSION["id"];
$mark=array();
	  $sql = "SELECT * FROM managertable where id='$mId';";
			  
      $result = mysqli_query($conn, $sql);
	  $rows = mysqli_num_rows($result);
        //     //echo'USER EXIST';
        if ($rows==1){
            while($rs  = mysqli_fetch_array($result)){ 

					    $rNo = $rs['assignedRail'];
             }
         }
		 


if($_SERVER["REQUEST_METHOD"] == "POST"){
	
if(!empty($_POST['current'])){
      $current = mysqli_real_escape_string($conn, $_POST['current']);
	  echo $current;
	  
    }
	if(!empty($_POST['next'])){
		
      $next = mysqli_real_escape_string($conn, $_POST['next']);
    }
				   
			 $sql2="UPDATE raildetails set current ='$current', next='$next' where id='$rNo';";
			 mysqli_query($conn, $sql2);
			 			 if(!isset($sql)){
				 die("Error $sql".mysqli_connect_error);
			 }
			 else
			 {
				 header("location:railInfo.php");
			 }
			 
			 
}


?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='../css/style.css' />
  </head>


<body>
<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
		    <li><a href="../home.php">Home</a></li>
		    <li><a href="manager.php">Profile</a></li>
            <li class="current"><a href="railinfo.php">About Rail</a></li>
			<li><a href="../logout.php">Details</a></li>
          </ul>
        </nav>
      </div>
    </header>
	
	<section id="boxes">
      <div align="center" class="container">
	  <form action="railinfo.php" method="post">
	<table> 
    <tr>
	<td> <label>Rail No: </label></td>
	<td> <label ><?php echo $rNo;?></label></td>
	</tr>
	<tr>
					<td><label> Current Location:</label></td>
					<td>
					<select name="current" required>
					<option value="" disabled selected >Select Current Location</option>
					
					<?php
					
					$sql2="SELECT * FROM raildetails where id= '$rNo' ;";
	                if($result2 = mysqli_query($conn, $sql2)) {
		            while($rows2 = mysqli_fetch_array($result2)){
		            $mark=explode(",",$rows2['stoppage']);
					foreach($mark as $stp){
					?>	
					<option value="<?php echo $stp ; ?>"><?php echo $stp ; ?></option>
					<?php
					}
					}
					}
					?>
					</select>
					</td>
				</tr>
	<tr>
	<td><label> Next Location:</label></td>
	<td>
					<select name="next" required>
					<option value="" disabled selected >Select next Location</option>
					
					<?php
					$sql2="SELECT * FROM raildetails where id= '$rNo' ;";
	                if($result2 = mysqli_query($conn, $sql2)) {
		            while($rows2 = mysqli_fetch_array($result2)){
		            $mark=explode(",",$rows2['stoppage']);
					foreach($mark as $stp){
					?>	
					<option value="<?php echo $stp; ?>"><?php echo $stp ; ?></option>
					<?php
					}
					}
					}
					?>
					</select>
					</td>
					</tr>
       <td><button type="submit" name= "Edit" value="Edit" onClick="update()" >Confirm</button></td>
       </tr>
	</table>
	</form>
	</div>
	</section>
	<script>
function update(){
 var x;
 if(confirm("Updated data Sucessfully") == true){
 x= "update";
 }
}
</script>
    <footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
	 </body>
  </html>
