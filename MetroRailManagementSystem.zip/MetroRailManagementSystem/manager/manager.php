<?php


 
include "../includes/db_connect.inc.php";
 session_start();

$mName = $mAge = $mGender= $mAddress=$mPno =$mEmail = $mPass=$mPassup= $mRail =$err = $uNameInDB = "" ;
$mId =$_SESSION["id"];
$mPass=$_SESSION["password"];	
	  $sql = "SELECT * FROM managertable where id='$mId';";
			  
      $result = mysqli_query($conn, $sql);
	  $rows = mysqli_num_rows($result);
        //     //echo'USER EXIST';
        if ($rows==1){
            while($rs  = mysqli_fetch_array($result)){ 
				  $mName = $rs['name'];
				   $mAge = $rs['age'];
				    $mGender = $rs['gender'];
					 $mAddress = $rs['address'];
					  $mPno = $rs['pno'];
					   $mEmail = $rs['email'];
					    $mRail = $rs['assignedRail'];
						 
                 

             }
         }
		 
		  // edit 
		 if(isset($_POST['Edit'])){
			 $mName=$_POST['m_name'] ;
			  $mAge=$_POST['m_age'] ;
			    $mAddress=$_POST['m_address'] ;
				 $mPno=$_POST['m_pno'] ;
				  $mEmail=$_POST['m_mail'] ;
				  $mPass=$_POST['m_pass'];
			 $_SESSION["password"]=$mPass;
			 $mPassup=password_hash($mPass, PASSWORD_DEFAULT);
			 $sql2="UPDATE managertable set name='$mName', age='$mAge',address='$mAddress',pno='$mPno',email='$mEmail',password='$mPassup' where id='$mId';";
			 $up=mysqli_query($conn, $sql2);
			 
			 if(!isset($sql)){
				 die("Error $sql".mysqli_connect_error);
			 }
			 else
			 {
				 header("location:manager.php");
			 }
			 
		 }
		  
		  
  
 

		 
		
 ?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel='stylesheet' type='text/css' href='../css/style.css' />
  </head>


<body>
<header>


      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li class="current"><a href="manager.php">Profile</a></li>
            <li><a href="railinfo.php">About Rail</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../login.php">Logout</a></li>
          </ul>
        </nav>
		
      </div>
    </header>
	
	
	
	
	
<form action ="manager.php" method="POST">
    <section id="boxes">
      <div align="left" class="container">
	  <h1 align="center" style="color:red">Welcome, <?php echo $mName ?></span></h1>	
	 <img align="right"src="../img/pro_pic.jpg" style="width:200px;height:200px;" >
	 
        <table>
		<tr>
    	<td> <label>ID: </label></td>
		<td> <label ><?php echo $mId;?></label></td>
		</tr>
		<tr>
		<td> <label>Name: </label></td>
        <td><input name ="m_name" value="<?php echo $mName;?>"> </input></td>
		</tr>
		
		<tr>
        <td> <label>Age: </label></td>
		<td><input name ="m_age" value="<?php echo $mAge;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Gender: </label></td>
		<td><label><?php echo $mGender;?></label></td>
		</tr>
		<tr>
		<td> <label>Address: </label></td>
        <td><input name ="m_address" value="<?php echo $mAddress;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Phone: </label></td>
	    <td><input name ="m_pno" value="<?php echo $mPno;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Email: </label></td>
		<td><input name ="m_mail" value="<?php echo $mEmail;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Password: </label></td>
		<td><input name ="m_pass" value="<?php echo $mPass;?>"> </input></td>
		</tr>
		<tr>
		<td> <label>Assigned Rail: </label></td>
		<td> <label ><?php echo $mRail;?></label></td>
		</tr>
		<tr>
		<td colspan=2> Want to edit your information? Click in the Edit button given below</td>
		</tr>
		<tr>
       <td><button type="submit" name= "Edit" value="Edit" onClick="update()">Edit</button></td>
       </tr>
       
		</table>
		   
      </div>
    </section>
	</form>
	<script>
function update(){
 var x;
 if(confirm("Updated data Sucessfully") == true){
 x= "update";
 }
}
</script>
	<div class="footer">
	<footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
	</div>
  </body>
  </html>