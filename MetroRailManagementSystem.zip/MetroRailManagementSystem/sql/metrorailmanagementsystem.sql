-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2019 at 10:32 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metrorailmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicanttable`
--

CREATE TABLE `applicanttable` (
  `id` int(10) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gmail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pno` int(10) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `applicanttable`
--

INSERT INTO `applicanttable` (`id`, `name`, `age`, `gender`, `type`, `address`, `gmail`, `pno`, `password`) VALUES
(11, 'tuni', 22, 'Female', 'Manager', 'gsgs', 'tuni@gmail.com', 1252, '$2y$10$9mAqxhSn4bUHo4kY8rOfpeG.KG0xCUbjFvPQV5gFjsi7FZTQKJjGa'),
(22, 'muni', 22, 'Male', 'Manager', 'hsgs', 'muni@gmail.com', 35862, '$2y$10$ZjfGnfLvmy.Zmpz.ytaj2uq2/3XRb6.3jovkfK6ul9WTvIXmVtK9a'),
(33, 'shalu', 5, 'Male', 'Passenger', 'gtxg', 'shalu@gmail.com', 9565, '$2y$10$j8EhlNq/b4BV92cXMzfEguFYZSmR89f8h21ZvSU.h9R685WtTI3zC'),
(44, 'malu', 10, 'Male', 'Passenger', 'xstg', 'malu@gmail.com', 9542, '$2y$10$i1Zd7L6ge8RTj916mZebwen3Bau7UZQPhA2I/FyectOrz2Au8.cE.'),
(55, 'min', 18, 'Female', 'Manager', 'hsb', 'min@yahoo.com', 59985, '$2y$10$8dJBe88MGsuz5dyPNvPdM.Onlcy/2.u2aebR5ZCMJKvesMyPWU0jm'),
(66, 'nin', 19, 'Male', 'Manager', 'hgv', 'nin@yahoo.com', 3235, '$2y$10$vWRvY/BhOM3uAtUvX7ZAsuKX1MWiNTAO7loXKDjW5hTJXAY3XpRJ.');

-- --------------------------------------------------------

--
-- Table structure for table `managertable`
--

CREATE TABLE `managertable` (
  `id` int(20) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(20) NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pno` int(20) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignedRail` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `managertable`
--

INSERT INTO `managertable` (`id`, `name`, `age`, `gender`, `address`, `pno`, `email`, `password`, `assignedRail`) VALUES
(1, 'as', 0, 'Female', 'g', 0, '0', '$2y$10$1qd', 0),
(2, 'ash', 30, 'Male', 'jhb', 0, '0', '$2y$10$JlN', 1),
(4, 'min', 30, 'male', 'hggggggg', 5523, 'min@gm.com', '123', 1),
(8, 'lll', 40, 'Male', 'jh', 0, '666', '$2y$10$jpj', 0),
(50, 'hh', 21, 'Female', 'bhbhb', 52521, '2541', '$2y$10$.cs3s0syhvI5E6wMbMcNqOPxqB1kzEAZ7W6iLO3eb1iCdHzfXQCTa', 2);

-- --------------------------------------------------------

--
-- Table structure for table `passengertable`
--

CREATE TABLE `passengertable` (
  `id` int(10) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gmail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pno` int(10) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `passengertable`
--

INSERT INTO `passengertable` (`id`, `name`, `age`, `gender`, `address`, `gmail`, `pno`, `password`, `balance`) VALUES
(1, 'chowa', 21, 'Female', 'hvhgv', 'ch@gmail.com', 0, '$2y$10$eMlsQ/NH7LlvAwA2HsL7eePDxza7gAxCRdFMdgs1kQ1AnVWUB3u52', 10),
(3, 'hali', 22, 'female', 'scds', 'hali@gmail.com', 1235, '123', 0),
(5, 'nm', 15, 'Female', 'hgv', 'nm@gmail.com', 1523, '222', 0),
(7, 'air', 22, 'Female', 'hhhh', 'a@gmail.com', 33233, '$2y$10$gt3cw2L5Oo9eeyHbJaCHOOye90GHRMNkxfs3eKMr6ZhnGuKY6jBOK', 20);

-- --------------------------------------------------------

--
-- Table structure for table `raildetails`
--

CREATE TABLE `raildetails` (
  `id` int(10) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stoppage` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignedmanager` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `raildetails`
--

INSERT INTO `raildetails` (`id`, `name`, `current`, `next`, `stoppage`, `assignedmanager`) VALUES
(1, 'metro1', 'not available', 'not available', 'Uttora North,Uttora Center,Uttora South,Pallabi,Mirpur 11,Mirpur 10,Kazipara,Shewrapara,Agargaon,Bijoy Sarani,Farmgate,Kawran Bazar,Shahbag,DU,BS,Motijhil ', 2),
(2, 'metro2', 'mirpur10', 'mirpur11', 'mirpur10,mirpur11,pallabi', 50);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicanttable`
--
ALTER TABLE `applicanttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `managertable`
--
ALTER TABLE `managertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `passengertable`
--
ALTER TABLE `passengertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `raildetails`
--
ALTER TABLE `raildetails`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
