
<?php
  session_start();

?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
	<link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
	  <header>
		  <div class="container">
			<div id="branding">
			  <h1><span class="highlight">Dhaka Metro Rail </span></h1>
			</div >
			<nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a> </li>
          </ul>
        </nav> 	
        		
		  </div>
	  </header>
	  <h1 align="center" style="color:red">Welcome, <?php echo $_SESSION["id"]; ?></span></h1>
	  <img align="right"src="../img/admin.jpg" style="width:400px;height:400px;" >
	  <section class="vertical-menu">
	  
	 
            <a href="admin.php" class="active" >home</a>
            <a href="applicant manager.php" >Pending Manager</a>
            <a href="available manager.php">Available manager</a>
            <a href="applicant passenger.php" >Pending passenger</a>
            <a href="available passenger.php">Available passenger</a>
			<a href="rail details.php">Rail Details</a>
	  </section>
	  <footer>
      <p>MetroRail Management System, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>