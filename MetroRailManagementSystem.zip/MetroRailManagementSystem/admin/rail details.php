

<?php
  session_start();

  if(!isset($_SESSION["id"])){
    header("Location: ../login.php");
  }
    include "../includes/db_connect.inc.php";

  $rId = $rName=$current=$next =$Stoppage=$nothing=$Assignedmanager=$dbmanager= $Err = $IdInDB = $result = "" ;
  $perPage = 5;
  $a = 1;
  $rows1=0;
  if(isset($_GET['next'])){
    $a = $_GET['next'];
  }
  else if(isset($_GET['prev'])){
    $a = $_GET['prev'];
  }
  else if(isset($_GET['pg'])){
    $a = $_GET['pg'];
  }
  
  $startingRow = ($a-1) * $perPage;
  if($startingRow<0 && isset($_GET['prev'])){
	  $startingRow=0;
	  $a = 1;
	  $nothing="nothing to show less";
	  
  }
		$sql1 = "SELECT * FROM managertable ";
		$result1=mysqli_query($conn,$sql1);
		$rows1 = mysqli_num_rows($result1);
		$rows1 = ceil($rows1 / $perPage);
		if(isset($_GET['next']) && $rows1 <= $_GET['next']){
			$a=$a-1;
			$nothing="nothing to show more";
		}	
	
	/* mysqli_real_escape_string() helps prevent sql injection */
  if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(!empty($_POST['rid'])){
      $rId = mysqli_real_escape_string($conn, $_POST['rid']);
    }
    if(!empty($_POST['rname'])){
      $rName = mysqli_real_escape_string($conn, $_POST['rname']);
    }
	if(!empty($_POST['stoppage'])){
      $Stoppage = mysqli_real_escape_string($conn, $_POST['stoppage']);
    }
	if(!empty($_POST['assignedmanager'])){
      $Assignedmanager = mysqli_real_escape_string($conn, $_POST['assignedmanager']);
	  $sqlUserCheck2="SELECT id FROM managertable WHERE name ='$Assignedmanager'";
	 $result2 = mysqli_query($conn, $sqlUserCheck2);

     while($row = mysqli_fetch_assoc($result2)){
      $dbmanager = $row['id'];
    }
    }

    $sqlUserCheck = "SELECT id FROM raildetails WHERE id = '$rId'";
    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $IdInDB = $row['id'];
    }
    if($IdInDB == $rId){
      $Err = "ID already exists!";
    }
    else{
		echo $dbmanager;
      $sql = "INSERT INTO raildetails (id,name,current,next,stoppage,assignedmanager)
              VALUES ('$rId','$rName','not available','not available','$Stoppage','$dbmanager');";

      mysqli_query($conn, $sql);
	        $sql2 = "UPDATE managertable SET assignedrail = '$rId' WHERE name ='$Assignedmanager';";

      mysqli_query($conn, $sql2);
    }
  }
  if(isset($_GET['delete'])){
		$rId = $_GET['delete'];
		$sql = "delete FROM raildetails where id='$rId';";
		$result=mysqli_query($conn,$sql);
		if($result){
			header("Location:rail details.php");
		}
		else{
			echo "check the query";
		}
	}
?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
	<link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
	  <header>
		  <div class="container">
			<div id="branding">
			  <h1><span class="highlight">Dhaka Metro Rail </span></h1>
			</div id="branding">
			<nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a></li>
          </ul>
        </nav> 	
        <h1 align="center" style="color:red">Welcome, <?php echo $_SESSION["id"]; ?></span></h1>		
		  </div>
	  </header>
	  <section>
		<div class="vertical-menu">
            <a href="admin.php">home</a>
            <a href="applicant manager.php">Pending Manager</a>
            <a href="available manager.php">Available manager</a>
            <a href="applicant passenger.php">Pending passenger</a>
            <a href="available passenger.php">Available passenger</a>
			<a href="rail details.php" class="active">Rail Details</a>
        </div>
		<div>
		<h1 align="center">Rail Details</h1>
			<form action="rail details.php" method="POST">
			<table align="center" id="sidebar1">
			<tr>
				<th>id</th>
				<th>name</th>
				<th>Assigned Manager</th>
				<th>Current Location</td>
				<th>Next Location</th>
				<th>Stoppage</th>
				<th>delete</th>
			</tr>
			<?php
					$sql = "SELECT * FROM raildetails LIMIT $startingRow, $perPage;";
					$result=mysqli_query($conn,$sql);
                    $rows = mysqli_num_rows($result);
					$totalPage = ceil($rows / $perPage);
						if ($rows>0){
            while($rs  = mysqli_fetch_array($result)){ 
                 $rId = $rs['id'];
				 $rName = $rs['name'];
				 $dbmanager=$rs['assignedmanager'];
				 $current = $rs['current'];
				 $next = $rs['next'];
				 $Stoppage = $rs['stoppage'];
				 $rows=$rows-1;
					?>
			<tr>
				<td ><?php echo $rId ?></td>
				<td ><?php echo $rName ?></td>
				<td ><?php echo $dbmanager ?></td>
				<td ><?php echo $current ?></td>
				<td ><?php echo $next ?></td>
				<td ><?php echo $Stoppage ?></td>
				<td><a  id="a1" href="rail details.php?delete=<?php echo $rId ?>">delete </a></td>
			</tr>
			<?php
			}
						}
		else{
			$empty="No  rail is available";
		}
					?>
		</table>
		<a href="#" id="button" > Add Rail</a>
		
		</div>
		<div class="modal">
		    <div  class="modal-content">
			<div class="close">+</div>
				<input type="text" name="rid" placeholder="Rail ID" required><br><br>
				<input type="textarea" name="rname"placeholder="Rail Name" required><br><br>
				<select name="assignedmanager" >
					<option value="" disabled selected >Assigned Manager</option>
					
					<?php
					$sql= "select name from managertable where assignedrail='';";
					$result=mysqli_query($conn,$sql);
					
					while($row=mysqli_fetch_assoc($result))
					{
					?>	
					<option ><?php echo $row['name'] ; ?></option>
					<?php
					}
					?>
					</select><br><br>
		 		<textarea  name="stoppage" rows="10" cols ="30" placeholder="write down the name of  stoppages sequential by comma-seprated "required></textarea><br><br>
				<button type="submit" >Submit</button>
			    <label style="color:red;"><?php echo $Err; ?></label>
			</div>
		</div>
		</form>
		<script>
		   document.getElementById('button').addEventListener('click',function (){
			   document.querySelector(".modal").style.display='flex';
		   });
		   document.querySelector('.close').addEventListener('click',function(){
			document.querySelector(".modal").style.display='none';   
		   });
   
          </script>
		  <a class="btnpg" id="a1" href="Rail details.php?prev=<?php echo $a-1; ?>">Start</a>
    <?php
      for($i=1; $i<=$totalPage*2; $i++){ ?>
        <a class="btnpg" href="rail details.php?pg=<?php echo $i; ?>"><?php echo $i; ?></a>
    <?php
      }
    ?>
    <a class="btnpg" id="a1" href="rail details.php?next=<?php echo $a+1; ?>">Next</a>
	<h1 align="center" style="color:red"><?php echo $nothing; ?></span></h1>
	  </section>
	  <footer>
      <p>MetroRail Management System, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
