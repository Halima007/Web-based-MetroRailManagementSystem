

<?php
  session_start();

  if(!isset($_SESSION["id"])){
    header("Location: ../login.php");
  }
      include "../includes/db_connect.inc.php";

$mId= $mName = $mAge = $mGender= $mAddress=$mNo =$mEmail=$mPassword=$AssignedRail =$empty=$nothing=$totalPage="";
  $perPage = 5;
  $a = 1;
  $rows1=0;
  if(isset($_GET['next'])){
    $a = $_GET['next'];
  }
  else if(isset($_GET['prev'])){
    $a = $_GET['prev'];
  }
  else if(isset($_GET['pg'])){
    $a = $_GET['pg'];
  }
  
  $startingRow = ($a-1) * $perPage;
  if($startingRow<0 && isset($_GET['prev'])){
	  $startingRow=0;
	  $a = 1;
	  $nothing="nothing to show less";
	  
  }
		$sql1 = "SELECT * FROM managertable ";
		$result1=mysqli_query($conn,$sql1);
		$rows1 = mysqli_num_rows($result1);
		$rows1 = ceil($rows1 / $perPage);
		if(isset($_GET['next']) && $rows1<= $_GET['next']){
			$a=$a-1;
			$nothing="nothing to show more";
		}

if(isset($_GET['delete'])){
		$mId = $_GET['delete'];
		$sql = "delete FROM managertable where id='$mId';";
		$result=mysqli_query($conn,$sql);
		if($result){
			header("Location:available manager.php");
		}
		else{
			echo "check the query";
		}
	}
?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
	<link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
	  <header>
		  <div class="container">
			<div id="branding">
			  <h1><span class="highlight">Dhaka Metro Rail </span></h1>
			</div id="branding">
			<nav>
          <ul>
            <li><a href="../home.php">Home</a></li>
			<li><a href="../details.php">Details</a></li>
			<li><a href="../logout.php">Logout</a></li>
          </ul>
        </nav> 	
        <h1 align="center" style="color:red">Welcome, <?php echo $_SESSION["id"]; ?></span></h1>		
		  </div>
	  </header>
	  <section>
		<div class="vertical-menu">
            <a href="admin.php">home</a>
            <a href="applicant manager.php">Pending Manager</a>
            <a href="available manager.php" class="active">Available manager</a>
            <a href="applicant passenger.php">Pending passenger</a>
            <a href="available passenger.php">Available passenger</a>
			<a href="rail details.php">Rail Details</a>
        </div>
				<div class="list">
		<h1 align="center">Available Manager List</h1>
		<h1 style="color:red" > <?php echo $empty ?></h1>
			<form action="available manager.php" method="post">
			<table align="center" id="sidebar1" >
			<tr>
				<th>id</th>
				<th>name</th>
				<th>age</td>
				<th>gender</th>
				<th>address</th>
				<th>phone </th>
				<th>email</th>
				<th>delete</th>
			</tr>
			<?php
					$sql = "SELECT * FROM managertable LIMIT $startingRow, $perPage;";
					$result=mysqli_query($conn,$sql);
                    $rows = mysqli_num_rows($result);
					$totalPage = ceil($rows / $perPage);
						if ($rows>0){
            while($rs  = mysqli_fetch_array($result)){ 
                 $mId = $rs['id'];
				 $mName = $rs['name'];
				 $mAge = $rs['age'];
				 $mGender = $rs['gender'];
				 $mAddress = $rs['address'];
				 $mNo = $rs['pno'];
				 $mEmail = $rs['email'];
				 $rows=$rows-1;
					?>
			<tr>
				<td ><?php echo $mId ?></td>
				<td ><?php echo $mName ?></td>
				<td ><?php echo $mAge ?></td>
				<td ><?php echo $mGender ?></td>
				<td ><?php echo $mAddress ?></td>
				<td ><?php echo $mNo ?></td>
				<td ><?php echo $mEmail ?></td>
				<td><a id="a1" href="available manager.php?delete=<?php echo $mId ?>">delete </a></td>
			</tr>
			<?php
			}
						}
		else{
			$empty="No  Manager is available";
		}
					?>
			</table>
			<a class="btnpg" id="a1" href="available manager.php?prev=<?php echo $a-1; ?>">Start</a>
    <?php
      for($i=1; $i<=$totalPage*2; $i++){ ?>
        <a class="btnpg"  href="available manager.php?pg=<?php echo $i; ?>"><?php echo $i; ?></a>
    <?php
      }
    ?>
    <a class="btnpg" id="a1" href="available manager.php?next=<?php echo $a+1; ?>">Next</a>
	<h1 align="center" style="color:red"><?php echo $nothing; ?></span></h1>
		</form>
	  </div>
	  </section>
	  <footer>
      <p>MetroRail Management System, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>