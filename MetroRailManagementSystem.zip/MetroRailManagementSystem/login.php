

<?php 
include "includes/db_connect.inc.php";
session_start();
$User_type = $Id =$Password = $message = "";

/* mysqli_real_escape_string() helps prevent sql injection */
if($_SERVER["REQUEST_METHOD"] == "POST"){
	if(!empty($_POST['type'])){
		$User_type = $_POST['type'];
	}
	if(!empty($_POST['id'])){
		$Id =mysqli_real_escape_string($conn, $_POST['id']);
	}
	if(!empty($_POST['password'])){
		$Password = $_POST['password'];
	}
    if($User_type=="Admin"){
		if($Id=="admin"){
			if($Password=="password"){
				$_SESSION['id'] = $Id;
				$_SESSION['type'] = $User_type;
				header("Location: ./admin/admin.php");
			}
			else{
			$message = "Wrong password!";
		}
		}
		else{
			$message = "Wrong Id!";
		}
		
	}
	    else if($User_type=="Passenger"){
	    $sqlUserCheck = "SELECT id, password FROM passengertable WHERE id = '$Id'";
		$result = mysqli_query($conn, $sqlUserCheck);
		$rowCount = mysqli_num_rows($result);
		if($rowCount < 1){
		$message = "User does not exist!";
		}
		else{
		while($row = mysqli_fetch_assoc($result)){
			$uPassInDB = $row['password'];

			if(password_verify($Password, $uPassInDB)){
				$_SESSION['id'] = $Id;
				$_SESSION['type'] = $User_type;
				$_SESSION['password'] = $Password;
				header("Location: ./passenger/passenger.php");
			}
			else{
				$message = "Wrong password!";
			}
		}
		}
		}
		else{
	    $sqlUserCheck = "SELECT id, password FROM managertable WHERE id = '$Id'";
		$result = mysqli_query($conn, $sqlUserCheck);
		$rowCount = mysqli_num_rows($result);
		if($rowCount < 1){
		$message = "User does not exist!";
		}
		else{
		while($row = mysqli_fetch_assoc($result)){
			$uPassInDB = $row['password'];
			if(password_verify($Password,$uPassInDB)){
				$_SESSION['id'] = $Id;
				$_SESSION['type'] = $User_type;
				$_SESSION['password'] = $Password;
				header("Location: ./manager/manager.php");
			}
			else{
				$message = "Wrong password!";
				echo $Password;
			}
		}
		}
		}
		
}
?>
<!DOCTYPE html>
<html>
<style>
body{
	margin: 0;
	padding: 0;
	background: #fff;

	color: #fff;
	font-family: Arial;
	font-size: 12px;
}

.body{
	position: absolute;
	top: 60px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background-image: url("./img/image.jpg");
	background-size: cover;
	-webkit-filter: blur(5px);
	z-index: 0;
}

.grad{
	position: absolute;
	top: 60px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0.65))); /* Chrome,Safari4+ */
	z-index: 1;
	opacity: 0.7;
}

.header{
	position: absolute;
	top: calc(50% - 35px);
	left: calc(50% - 255px);
	z-index: 2;
}

.header div{
	float: left;
	color:#0d0d0d;
	font-family: 'Exo', sans-serif;
	font-size: 35px;
	font-weight: 200;
}

.header div span{
	color:  #1aff1a !important;
}

.login{
	position: absolute;
	top: calc(50% - 75px);
	left: calc(50% - 50px);
	height: 150px;
	width: 350px;
	padding: 10px;
	z-index: 2;
}

.login input[type=text]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}

.login input[type=password]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
	margin-top: 10px;
}

.login input[type=button]{
	width: 260px;
	height: 35px;
	background: #fff;
	border: 1px solid #fff;
	cursor: pointer;
	border-radius: 2px;
	color: #a18d6c;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 6px;
	margin-top: 10px;
}

.login input[type=button]:hover{
	opacity: 0.8;
}

.login input[type=button]:active{
	opacity: 0.6;
}

.login input[type=text]:focus{
	outline: none;
	border: 1px solid rgba(255,255,255,0.9);
}

.login input[type=password]:focus{
	outline: none;
	border: 1px solid rgba(255,255,255,0.9);
}

.login input[type=button]:focus{
	outline: none;
}

::-webkit-input-placeholder{
   color: rgba(255,255,255,0.6);
}

::-moz-input-placeholder{
   color: rgba(255,255,255,0.6);
}
#a2{
	color : white;
}
</style>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="home.php">Home</a></li>
            <li class="current"><a href="login.php">LOG IN</a></li>
            <li><a href="registration.php">Registration</a></li>
			<li><a href="details.php">Details</a></li>
          </ul>
        </nav>
      </div>
    </header>

		<section class="container">
		<div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div>Metro<span>Rail</span></div>
		</div>
		<br>
		
			<form action="login.php" method="post">
			<div class="login">
			<table align="center">
			
			
			<tr>
			<td><label>User Type: </label></td>
			<td>
			<select name="type">
			<option name="type" value="Admin"> Admin</option>
			<option name="type" value="Manager"> Manager</option>
			<option name="type" value="Passenger">Passenger</option>
			</select>
			</td>
			</tr>
				<tr>
					<td><label><b> Id: </b></label></td>
					<td><input name ="id" type="text"></td>
				</tr>

				<tr>
					<td><label><b> Password: </b></label></td>
					<td><input name = "password" type="password"></td>
				</tr>

				<tr>
				    <td></td>
					<td align = "right">
						<input type="submit" name= "Login" value="Login">
						<span style="color:red"><?php echo $message; ?></span>
					</td>
				</tr>
				<tr>
					<td colspan="2"><a id= "a2" href="registration.php"> Do not have an account? Register now!!</a></td>
				</tr>
			</table>
            </div>
		</form>
    </section>

    <footer>
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>