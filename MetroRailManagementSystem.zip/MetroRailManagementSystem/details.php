

<?php 
session_start();
include "includes/db_connect.inc.php";
$url="login.php";
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Admin" ){
    $url="./admin/admin.php";
  }
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Manager" ){
    $url="./manager/manager.php";
  }
if(isset($_SESSION["type"]) && $_SESSION["type"]=="Passenger" ){
    $url="./passenger/passenger.php";
  }    
$currentlabel="";
$nextlabel="";
$namelabel="";
$current=$next=$name=$err="";

if($_SERVER["REQUEST_METHOD"] == "POST"){
$currentlabel="Current Location";
$nextlabel="Next Location";
$namelabel="Train Name";
if(empty($_POST['Rail_number'])){
      $err="select a rail name";
    }
	else
	{
		$name = mysqli_real_escape_string($conn, $_POST['Rail_number']);
		$sqlUserCheck = "SELECT name, current,next FROM raildetails WHERE name = '$name'";
		$result = mysqli_query($conn, $sqlUserCheck);
		$rowCount = mysqli_num_rows($result);
        while($row = mysqli_fetch_assoc($result)){
		$name=$row['name'];
		$current=$row['current'];
		$next=$row['next'];
}
	}

}

?>
<!DOCTYPE html>
<html>
<style>

#popup{display:none; 
  background:#ccff66; 
  border:1px solid black; 
  width:80%; 
  height:160px;}
  
  #popup1{display:none; 
  background:#ccff66; 
  border:1px solid black; 
  width:80%; 
  height:160px;}
  
   #popup2{display:none; 
  background:#ccff66; 
  border:1px solid black; 
 width:80%; 
  height:160px;}
  
  .buttonpop {
  background-color: #00995c;
  border: none;
  color: white;
  padding: 12px 20px;
  border-radius: 12px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
  display: inline-block;
  text-decoration: none;
  cursor: pointer;
}

.buttonpop:hover {opacity: 1}
  
</style>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online ticketing and account managing for metro rail passenger">
	<meta name="keywords" content="online ticket purchase,balance check,rail info,recharge,updated info">
  	<meta name="author" content="Bangladesh government">
    <title>MetroRail | Welcome</title>
	<link rel="stylesheet" href="./css/style.css">
  </head>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Dhaka Metro Rail </span></h1>
        </div>
        <nav>
          <ul>
            <li><a href="home.php">Home</a></li>
            <li ><a href=<?php echo $url ?>>LOG IN</a></li>
            <li ><a href="registration.php">Registration</a></li>
			<li class="current"><a href="details.php">Details</a></li>
          </ul>
        </nav>
      </div>
    </header>

     	<section class="container">
	<h1 align="center" style="color:red">Rail Details</h1>
            <form action="details.php" method="POST">
			<div>
			 <h2 align="right">Current Information of rail:</h2>
			 <table align="right">
				<tr>
					<td><label><?php echo $namelabel ?> :</label></td>
					<td align="left"><label><?php echo $name ?></td>
				</tr>
				<tr>
					<td><label><?php echo $currentlabel ?> :</label></td>
					<td align="left"><label><?php echo $current ?></label></td>
				</tr>
				<tr>
					<td><label><?php echo $nextlabel ?> :</label></td>
					<td align="left"><label><?php echo $next ?></td></td>
				</tr>
			</table>
			<table align="left">
				<tr>
					<td><label>Rail no: </label></td>
					<td>
					<select name="Rail_number" required>
					<option value="" disabled selected >Select Train</option>
					
					<?php
					$sql= "select name from raildetails";
					$result=mysqli_query($conn,$sql);
					
					while($row=mysqli_fetch_assoc($result))
					{
					?>	
					<option ><?php echo $row['name'] ; ?></option>
					<?php
					}
					?>
					</select>
					</td>
				</tr>
				<tr>
				<td><span style="color:red"><?php echo $err; ?></span></td>
					<td align ="right"><input type="submit" name="search" value="Search"></td>
				</tr>			
				</table>		
				</div>
						 
			</form>

			<br><br><br>
			
			
			
	</section>
	
	
	<section id="newsletter">
      <div class="container">
      </div>
    </section>

	
		<section id="boxes">
		<div class="container">
		<div align="left"class="box">
		<img src="./img/about.jpg" style="width:100px;height:100px;"><br>
		<button class= "buttonpop" onclick="document.getElementById('popup').style.display='block'">About</button>
		<div id="popup">
		<p > We have 6 metro and 16 stations available now. You can get a metro with wait times of approximately 4 minutes.  </p>
		<button onclick="document.getElementById('popup').style.display='none'">Hide</button>
		</div>
		</div>
        <div align="center" class="box" >
        <img src="./img/stations.jpg" style="width:100px;height:100px;"><br>
     
		
		<button class= "buttonpop" onclick="document.getElementById('popup1').style.display='block'">Stations</button>
		<div id="popup1">
		<p>1.Uttora North 2.Uttora Center 3.Uttora South 4.Pallabi 5.Mirpur-11
		6.Mirpur-10 7.Kazipara 8.Shewrapara 9.Agargaon 10.Bijoy Sarani 11.Farmgate 12.Kawran Bazar
		13.Shahbag 14.Dhaka University 15.Bangladesh Secretariat 16.Motijhil</p>
		
		<button onclick="document.getElementById('popup1').style.display='none'">Hide</button>
		</div>
		</div>
		
		<div align="right"class="box">
		<img src="./img/contact.jpg" style="width:100px;height:100px;"><br>
		<button class= "buttonpop" onclick="document.getElementById('popup2').style.display='block'">Contact Us</button>
		<div id="popup2">
		<p > We are available for any inquire about metro rail. Our hotline Number: 01713698756</p>
		<button onclick="document.getElementById('popup2').style.display='none'">Hide</button>
		</div>
		</div>
		</section>


    <footer >
      <p>MetroRail Management, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>